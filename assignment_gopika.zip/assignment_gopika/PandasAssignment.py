#!/usr/bin/env python
# coding: utf-8

# In[2]:


import pandas as pd 
import numpy as np


# In[ ]:


#1.Combine four series to form and create a Dataframe with name series_data. Use the Dataframe and perform following operations.


# In[3]:


#1.a.Display first five rows and last five rows using pandas method
s1 = pd.Series([1,2,3,4,5,6,7,8,9,10])
s2 = pd.Series(['jk','tan','bam','mickey','rj','felix','han','rose','nancy','sana'])
s3 = pd.Series(['boxer','designer','therapist','doctor','singer','actor','engineer','assitant','nurse','runner'])
s4 = pd.Series(['india','australia','korea','lasVegas','uae','qatar','usa','nz','taiwan','hawai'])
s5 = pd.Series([24,34,22,30,43,22,27,33,28,25])
s = pd.DataFrame({'num' :s1,'name':s2,'job':s3,'place':s4,'age':s5})


# In[4]:


print(s.head())


# In[5]:


print(s.tail())


# In[6]:


#1.b.Convert the index of a series into a column of a dataframe.
s['index']=s.index
s


# In[7]:


#1.c. drop the index column of the dataframe
s.drop('index',axis = 1)


# In[8]:


#1.d.Display the frequency counts of unique items of a series data.
sr= pd.Series([10,2,4,10,3,5,4,3,5,6,5,7,7,3,8,10,5,3,2])
sr.value_counts()


# In[9]:


#2.How to stack two random series vertically and horizontally?
s2.append(s4) #vertically


# In[10]:


horz = pd.concat([s2,s4],axis=1) #vertically
horz


# In[11]:


#3.How to convert a numpy array to a Dataframe of given shape?
num1 = np.array([10,20,30,40,50,60])
arr1_df = pd.DataFrame(num1)
arr1_df


# In[12]:


#4.Find the index positions of items common in  series A and series B using numpy.where() and pd.Index() methods?
serA = pd.Series([2,1,4,6,3,8,7,9,10,5,15,13,12,14])
serB = pd.Series([1,3,5,7,10])
res1 = [pd.Index(serA).get_loc(i) for i in serB]
res1


# In[13]:


#using numpy.where()
serA = pd.Series([2,1,4,6,3,8,7,9,10,5,15,13,12,14])
serB = pd.Series([1,3,5,7,10])
res1 = [np.where(i == serA)[0].tolist()[0] for i in serB]
res1


# In[14]:


#5.How to convert the first character of each Categorical value in a series to uppercase keeping rest of values to lowercase?
uppercase = pd.Series(['java','php','sql','python',])
pd.Series([i.title()for i in uppercase])


# In[15]:


#6.How to filter valid emails from a series data using following pattern to be matched?
#pattern ='[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}'
import re
pattern = '[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}'
emails = pd.Series(['books at amazom.com', 'james@egypt.com', 'jones@yahoo.in', 'bigdata@gmail.com'])
emails.str.findall(pattern,flags=re.IGNORECASE)


# In[16]:


#7.Analysing earthquake data using url: 
#a.Create a Datafrme using URL
earthquake_df = pd.read_csv("https://raw.githubusercontent.com/ammishra08/MachineLearning/master/Datasets/earthquakes_2014.csv",header = 0)


# In[17]:


#7.b.Display Info of the Dataframe
display(earthquake_df)


# In[34]:


#7.c.Convert time column from object to datetime format [Hint: Use pd.to_datetime()] #ERROR
res2 = pd.to_datetime(earthquake_df['time'],format="%m%d%Y, %H:%M:%S")
res2


# In[19]:


#7.d.Rename columns latitude, longitude, depth, mag to  ‘Lat’, ‘Long’, ‘D, M’ column names.
earthquake_new = earthquake_df.rename(columns={'latitude':'Lat','longitude':'Long','depth':'D','mag':'M'})
display(earthquake_new)


# In[20]:


#7.e.Find out invalid data (the nan values from missing points)
earthquake_df.isnull()


# In[21]:


#7.f.Drop all nan values from the existing data.
earthquake_df.dropna()


# In[22]:


#7.g.Replace the invalid data with central tendencies.
earthquake_df1 = earthquake_df[['nst','gap','dmin']]=earthquake_df[['nst','gap','dmin']].apply(lambda x:x.fillna(x.mean()))
earthquake_df1


# In[23]:


#8.a.Load the data file
houseSale_df=pd.read_csv("https://raw.githubusercontent.com/ammishra08/MachineLearning/master/Datasets/house_sales_data.csv",header = 0)
houseSale_df


# In[24]:


#8.b.Sorting the Rows Data using Column ‘price’ and reset index & update the dataframe.
houseSale_df['price'].sort_values()


# In[25]:


#8.c.Slice the rows and columns using iloc row positions 100 to 300 , columns 2 to 9 positions.
houseSale_df.iloc[100:300,2:9]


# In[26]:


#8.d.Filter all columns with letter ‘a’ in it.
houseSale_df.filter(like = 'a')


# In[27]:


#8.e.Filter the columns with Price > 250000 and the view column is True.
res3 = [(houseSale_df.price > 250000) & (houseSale_df.view.isnull())]
res3


# In[28]:


#8.f.Compute the average price of a house with sqft_living  > 25000 and the view column  is True.
houseSale_df[(houseSale_df.sqft_living>250000) & (houseSale_df.view.isnull())]


# In[ ]:




