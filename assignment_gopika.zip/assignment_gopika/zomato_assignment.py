#!/usr/bin/env python
# coding: utf-8

# In[2]:


import pandas as pd
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns


# In[3]:


zomato_df= pd.read_csv("D:/Data/zomato_restaurants.csv")
display(zomato_df)


# In[4]:


zomato_df.head()


# In[5]:


#a.Plot the Count of Famous Food Outlets / Restaurants in Bengaluru
zomato_df['name'].value_counts()


# In[6]:


#b.Display accepting online orders vs not accepting online orders count % distribution
plt.figure(figsize = (6,6))
plt.pie(zomato_df['online_order'].value_counts(), labels = zomato_df['online_order'].unique(), autopct='%1.2f%%', explode = [0,0])
plt.legend()
plt.show()


# In[7]:


#c.Find the popular restaurant type in Bengaluru. 
zomato_df['name'].value_counts()


# In[8]:


#d.Display accepting Table Booking vs Not accepting table booking count % distribution
plt.figure(figsize = (6,6))
plt.pie(zomato_df['book_table'].value_counts(), labels = zomato_df['book_table'].unique(), autopct='%1.2f%%', explode = [0,0])
plt.legend()
plt.show()


# In[9]:


#e.Histogram and Box Plot of Approx Cost Distribution. Note: Replace ‘,’ from the values using replace(), lambda function with replace()
zomato_res = zomato_df['approx_cost(for two people)'].str.replace(",","")
plt.figure(figsize=(10,8))
sns.boxplot(data = zomato_res, palette = 'plasma')


# In[10]:


#e histogram
zomato_df['approx_cost(for two people)'].hist(bins = 15, figsize=(35, 10),color = 'blue')
plt.title('histogram plot of approx_cost', fontsize = 12)
plt.xlabel('approx_cost(for 2 people)')
plt.ylabel('frequency(in range)')
plt.show()


# In[11]:


#f.Histogram and Box Plot of Restaurant Rating Distribution. Note: Replace ‘,’ from the values using replace(), lambda function with replace()
box_plot = zomato_df['rate'].str.replace("/","")
plt.figure(figsize=(10,8))
sns.boxplot(data = box_plot, palette = 'plasma')


# In[ ]:


#g.Rate vs Approx Cost (for two people). Also categorise them into online_order available or not. 


# In[16]:


#h.Distribution of Approx Cost for two people. Is it skewed?
plt.figure(figsize =(11,8))
sns.distplot(zomato_df['approx_cost(for two people)'], color = 'deeppink')


# In[18]:


#i.Is there any difference b/w votes of restaurants accepting and not accepting online orders?
plt.style.use('ggplot')
sns.lmplot(x = 'votes',y = 'votes', hue = 'online_order', height = 8, data = zomato_df)


# In[13]:


#j.Which are the Top 20 most common restaurant types in Bengaluru?
top = zomato_df['rest_type'].value_counts()
top[0:19]


# In[14]:


#k.Which are the Top 20 most common Locations with most Number of Restaurants?
rest_1 = zomato_df['location'].value_counts()
rest_1[0:19]


# In[ ]:




